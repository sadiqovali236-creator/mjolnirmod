# Mjölnir Mod (Forge 1.20.1, Java 17)

## Nasıl çalışır
- **Doğma:** Overworld'de yaklaşık her 20 chunk'ta bir "Mjölnir Taşı" çıkar (sadece yeni oluşan chunk'larda).
- **Layık olma:** Taşa sağ tıkla. 50 seviye (level) gerekir. Layıksan çekiç envanterine gelir.
- **Güçler:** Çekiç elindeyken Güç II, Direnç I, Hız I, Zıplama II ve yıldırım hasarına bağışıklık.
- **Fırlatma:** Blok koyma tuşunu (sağ tık / "sec") basılı tut → çekiç elinde döner. Bırak → fırlar (ne kadar uzun basılı tutarsan o kadar hızlı).
- **Takılma:** Bir bloğa saplanır. Yolundaki canlılara hasar verir.
- **Vurma:** Vurma tuşu (sol tık / "pri") normal çalışır, çekiçle düz vurursun.
- **Geri çağırma:** Elin boşken aynı blok koyma tuşuna bas → çekiç sana doğru uçar (ışınlanmaz). Saplıyken yanına gidip sağ tıkla da alabilirsin.
- **Yıldırım ışını:** Varsayılan tuş R. Ayarlar > Kontroller > Mjölnir bölümünden değiştirilir. 2 sn bekleme süresi var.

## Test için
- `/give @s mjolnirmod:mjolnir_stone` ile taşı yere koy, `/xp set @s 50 levels` ile layık ol.

## Derleme
- Bilgisayarda: `gradlew` dosyalarını Forge MDK'dan kopyalayıp `./gradlew build`
- Telefonda: `.github/workflows/build.yml` ile GitHub Actions derlesin → jar `build/libs/mjolnirmod-1.0.0.jar`
