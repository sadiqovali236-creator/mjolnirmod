package com.ali.mjolnirmod;

import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.EntityStruckByLightningEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MjolnirMod.MOD_ID)
public class CommonEvents {
    // Mjolnir elindeyken yildirim sana zarar vermez
    @SubscribeEvent
    public static void onStruckByLightning(EntityStruckByLightningEvent event) {
        if (event.getEntity() instanceof Player player
                && player.getMainHandItem().is(ModItems.MJOLNIR.get())) {
            event.setCanceled(true);
        }
    }
}
