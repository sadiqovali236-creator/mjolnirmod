package com.ali.mjolnirmod.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Istemciden sunucuya: firlat / geri cagir / yildirim. */
public class MjolnirActionPacket {
    public static final byte THROW = 0;
    public static final byte RECALL = 1;
    public static final byte LIGHTNING = 2;

    private final byte action;
    private final int charge;

    public MjolnirActionPacket(byte action, int charge) {
        this.action = action;
        this.charge = charge;
    }

    public static void encode(MjolnirActionPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.action);
        buf.writeVarInt(msg.charge);
    }

    public static MjolnirActionPacket decode(FriendlyByteBuf buf) {
        return new MjolnirActionPacket(buf.readByte(), buf.readVarInt());
    }

    public static void handle(MjolnirActionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                MjolnirActions.handle(player, msg.action, msg.charge);
            }
        });
        context.setPacketHandled(true);
    }
}
