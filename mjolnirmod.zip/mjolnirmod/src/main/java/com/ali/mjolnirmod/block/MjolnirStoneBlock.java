package com.ali.mjolnirmod.block;

import com.ali.mjolnirmod.ModItems;
import com.ali.mjolnirmod.item.MjolnirItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class MjolnirStoneBlock extends Block {
    private static final VoxelShape SHAPE = Shapes.or(
            Block.box(1, 0, 1, 15, 5, 15),
            Block.box(3, 5, 3, 13, 8, 13),
            Block.box(7, 8, 7, 9, 12, 9),
            Block.box(3, 12, 5.5, 13, 16, 10.5));

    public MjolnirStoneBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }

        if (!MjolnirItem.isWorthy(player)) {
            player.displayClientMessage(
                    Component.translatable("message.mjolnirmod.unworthy", MjolnirItem.WORTHY_LEVEL), true);
            level.playSound(null, pos, SoundEvents.ANVIL_PLACE, SoundSource.BLOCKS, 0.8F, 0.6F);
            return InteractionResult.CONSUME;
        }

        ItemStack hammer = new ItemStack(ModItems.MJOLNIR.get());
        if (!player.getInventory().add(hammer)) {
            player.drop(hammer, false);
        }

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(pos));
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }

        level.setBlock(pos, Blocks.COBBLESTONE.defaultBlockState(), 3);
        player.displayClientMessage(Component.translatable("message.mjolnirmod.worthy"), true);
        return InteractionResult.CONSUME;
    }
}
