package com.ali.mjolnirmod.world;

import com.ali.mjolnirmod.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

public class MjolnirStoneFeature extends Feature<NoneFeatureConfiguration> {
    public MjolnirStoneFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos pos = context.origin();
        BlockPos below = pos.below();
        BlockState belowState = level.getBlockState(below);

        if (!level.isEmptyBlock(pos)
                || !belowState.getFluidState().isEmpty()
                || !belowState.isFaceSturdy(level, below, Direction.UP)) {
            return false;
        }

        level.setBlock(pos, ModBlocks.MJOLNIR_STONE.get().defaultBlockState(), 2);
        return true;
    }
}
