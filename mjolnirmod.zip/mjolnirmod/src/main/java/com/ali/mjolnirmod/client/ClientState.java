package com.ali.mjolnirmod.client;

import com.ali.mjolnirmod.network.MjolnirActions;

/** Sadece istemci: sol tik basili tutma durumu. */
public class ClientState {
    public static boolean charging = false;
    public static int charge = 0;

    public static void reset() {
        charging = false;
        charge = 0;
    }

    public static void tickCharge() {
        charging = true;
        charge = Math.min(charge + 1, MjolnirActions.MAX_CHARGE);
    }
}
