package com.ali.mjolnirmod;

import com.ali.mjolnirmod.item.MjolnirItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MjolnirMod.MOD_ID);

    public static final RegistryObject<Item> MJOLNIR = ITEMS.register("mjolnir",
            () -> new MjolnirItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> MJOLNIR_STONE = ITEMS.register("mjolnir_stone",
            () -> new BlockItem(ModBlocks.MJOLNIR_STONE.get(), new Item.Properties().rarity(Rarity.EPIC)));
}
