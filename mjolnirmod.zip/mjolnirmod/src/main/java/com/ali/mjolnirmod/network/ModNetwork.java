package com.ali.mjolnirmod.network;

import com.ali.mjolnirmod.MjolnirMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MjolnirMod.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.registerMessage(0, MjolnirActionPacket.class,
                MjolnirActionPacket::encode, MjolnirActionPacket::decode, MjolnirActionPacket::handle);
    }
}
