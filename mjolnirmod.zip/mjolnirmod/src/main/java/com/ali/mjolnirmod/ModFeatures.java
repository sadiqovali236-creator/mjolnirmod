package com.ali.mjolnirmod;

import com.ali.mjolnirmod.world.MjolnirStoneFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(ForgeRegistries.FEATURES, MjolnirMod.MOD_ID);

    public static final RegistryObject<MjolnirStoneFeature> MJOLNIR_STONE =
            FEATURES.register("mjolnir_stone", MjolnirStoneFeature::new);
}
