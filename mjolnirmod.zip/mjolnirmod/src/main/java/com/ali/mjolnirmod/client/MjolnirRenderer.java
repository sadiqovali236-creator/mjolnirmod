package com.ali.mjolnirmod.client;

import com.ali.mjolnirmod.ModItems;
import com.ali.mjolnirmod.entity.MjolnirEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class MjolnirRenderer extends EntityRenderer<MjolnirEntity> {
    private final ItemRenderer itemRenderer;

    public MjolnirRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public void render(MjolnirEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.translate(0.0D, entity.getBbHeight() / 2.0D, 0.0D);

        // Cekicin duzlemi ucus yonuyle ayni hizada olsun
        poseStack.mulPose(Axis.YP.rotationDegrees(-entity.getYRot() - 90.0F));

        if (entity.getState() != MjolnirEntity.STUCK) {
            float spin = (entity.tickCount + partialTick) * 40.0F;
            poseStack.mulPose(Axis.ZP.rotationDegrees(spin));
        }

        poseStack.scale(2.0F, 2.0F, 2.0F);
        this.itemRenderer.renderStatic(new ItemStack(ModItems.MJOLNIR.get()), ItemDisplayContext.GROUND,
                packedLight, OverlayTexture.NO_OVERLAY, poseStack, buffer, entity.level(), entity.getId());

        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(MjolnirEntity entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
