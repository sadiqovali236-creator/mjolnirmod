package com.ali.mjolnirmod.entity;

import com.ali.mjolnirmod.ModEntities;
import com.ali.mjolnirmod.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

public class MjolnirEntity extends Projectile {
    private static final EntityDataAccessor<Integer> STATE =
            SynchedEntityData.defineId(MjolnirEntity.class, EntityDataSerializers.INT);

    public static final int FLYING = 0;
    public static final int STUCK = 1;
    public static final int RETURNING = 2;

    private static final double MAX_DISTANCE = 45.0;
    private static final int MAX_FLIGHT_TICKS = 60;
    private static final float DAMAGE = 12.0F;

    private BlockPos stuckPos = BlockPos.ZERO;
    private int returnTicks = 0;
    private int flightTicks = 0;
    private final Set<Integer> hitIds = new HashSet<>();
    private ItemStack stack = new ItemStack(ModItems.MJOLNIR.get());

    public MjolnirEntity(EntityType<? extends MjolnirEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public MjolnirEntity(Level level, LivingEntity owner) {
        this(ModEntities.MJOLNIR.get(), level);
        this.setOwner(owner);
        this.setPos(owner.getX(), owner.getEyeY() - 0.15D, owner.getZ());
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(STATE, FLYING);
    }

    public int getState() {
        return this.entityData.get(STATE);
    }

    private void setState(int state) {
        this.entityData.set(STATE, state);
    }

    public void setStack(ItemStack stack) {
        this.stack = stack.copy();
    }

    @Override
    public void tick() {
        super.tick();
        switch (getState()) {
            case STUCK -> tickStuck();
            case RETURNING -> tickReturning();
            default -> tickFlying();
        }
    }

    // ---------------- Firlatma ----------------

    private void tickFlying() {
        if (level().isClientSide()) {
            spawnTrail();
            return;
        }

        flightTicks++;
        Entity owner = getOwner();
        if (flightTicks > MAX_FLIGHT_TICKS
                || (owner != null && owner.distanceToSqr(this) > MAX_DISTANCE * MAX_DISTANCE)) {
            startReturning();
            return;
        }

        Vec3 start = position();
        Vec3 motion = getDeltaMovement();
        Vec3 end = start.add(motion);

        HitResult blockHit = level().clip(
                new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        if (blockHit.getType() != HitResult.Type.MISS) {
            end = blockHit.getLocation();
        }

        damageAlongPath(start, end);

        if (blockHit.getType() == HitResult.Type.BLOCK) {
            stickInBlock((BlockHitResult) blockHit, motion);
            return;
        }

        setPos(end);
        faceMotion(motion);
    }

    private void stickInBlock(BlockHitResult hit, Vec3 motion) {
        stuckPos = hit.getBlockPos();
        Vec3 dir = motion.lengthSqr() > 1.0E-6 ? motion.normalize() : Vec3.ZERO;
        setPos(hit.getLocation().subtract(dir.scale(0.2D)));
        setDeltaMovement(Vec3.ZERO);
        setState(STUCK);
        level().playSound(null, getX(), getY(), getZ(),
                SoundEvents.TRIDENT_HIT_GROUND, SoundSource.NEUTRAL, 1.2F, 0.8F);
        if (level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(),
                    15, 0.3D, 0.3D, 0.3D, 0.1D);
        }
    }

    // ---------------- Blokta takili ----------------

    private void tickStuck() {
        if (level().isClientSide()) {
            return;
        }
        // Takildigi blok yok olduysa otomatik geri doner
        if (tickCount % 10 == 0) {
            BlockState state = level().getBlockState(stuckPos);
            if (state.getCollisionShape(level(), stuckPos).isEmpty()) {
                startReturning();
            }
        }
    }

    // ---------------- Geri donus ----------------

    public void startReturning() {
        if (getState() == RETURNING) {
            return;
        }
        hitIds.clear();
        returnTicks = 0;
        setState(RETURNING);
        level().playSound(null, getX(), getY(), getZ(),
                SoundEvents.TRIDENT_RETURN, SoundSource.NEUTRAL, 1.0F, 1.0F);
    }

    private void tickReturning() {
        if (level().isClientSide()) {
            spawnTrail();
            return;
        }

        Entity owner = getOwner();
        if (!(owner instanceof Player player) || !player.isAlive()) {
            // Sahibi yok / olmus: cekic yere dusen esya olur
            spawnAtLocation(stack.copy());
            discard();
            return;
        }

        returnTicks++;
        Vec3 target = player.position().add(0.0D, player.getBbHeight() * 0.6D, 0.0D);
        Vec3 toPlayer = target.subtract(position());
        double dist = toPlayer.length();

        if (dist < 1.6D) {
            giveBack(player);
            return;
        }

        double speed = Math.min(2.2D, 0.5D + returnTicks * 0.12D);
        Vec3 move = toPlayer.normalize().scale(Math.min(speed, dist));
        Vec3 from = position();

        setDeltaMovement(move);
        damageAlongPath(from, from.add(move));
        setPos(from.add(move));
        faceMotion(move);
    }

    private void giveBack(Player player) {
        ItemStack toGive = stack.copy();
        if (player.getMainHandItem().isEmpty()) {
            player.setItemInHand(InteractionHand.MAIN_HAND, toGive);
        } else if (!player.getInventory().add(toGive)) {
            player.drop(toGive, false);
        }
        level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 1.0F, 0.9F);
        discard();
    }

    // ---------------- Hasar ----------------

    private void damageAlongPath(Vec3 from, Vec3 to) {
        Entity owner = getOwner();
        AABB area = new AABB(from, to).inflate(1.0D);
        for (Entity target : level().getEntities(this, area,
                e -> e instanceof LivingEntity && e.isAlive() && e != owner && !hitIds.contains(e.getId()))) {
            AABB box = target.getBoundingBox().inflate(0.4D);
            if (!box.contains(from) && box.clip(from, to).isEmpty()) {
                continue;
            }
            hitIds.add(target.getId());
            DamageSource source = damageSources().thrown(this, owner == null ? this : owner);
            if (target.hurt(source, DAMAGE) && target instanceof LivingEntity living) {
                Vec3 dir = to.subtract(from);
                if (dir.lengthSqr() > 1.0E-6) {
                    dir = dir.normalize();
                    living.knockback(0.6D, -dir.x, -dir.z);
                }
            }
            level().playSound(null, target.blockPosition(),
                    SoundEvents.TRIDENT_HIT, SoundSource.NEUTRAL, 1.0F, 1.0F);
        }
    }

    // ---------------- Yardimcilar ----------------

    private void faceMotion(Vec3 m) {
        if (m.lengthSqr() < 1.0E-6) {
            return;
        }
        double horizontal = m.horizontalDistance();
        setYRot((float) (Mth.atan2(-m.x, m.z) * (180.0D / Math.PI)));
        setXRot((float) (Mth.atan2(m.y, horizontal) * (180.0D / Math.PI)));
    }

    private void spawnTrail() {
        level().addParticle(ParticleTypes.ELECTRIC_SPARK,
                getX() + random.nextGaussian() * 0.1D,
                getY() + 0.3D + random.nextGaussian() * 0.1D,
                getZ() + random.nextGaussian() * 0.1D,
                0.0D, 0.0D, 0.0D);
    }

    // Blokta takiliyken sahibi sag tikla da alabilir
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (getState() == STUCK && player == getOwner()) {
            if (!level().isClientSide()) {
                giveBack(player);
            }
            return InteractionResult.sidedSuccess(level().isClientSide());
        }
        return InteractionResult.PASS;
    }

    @Override
    public boolean isPickable() {
        return getState() == STUCK;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("State", getState());
        tag.put("StuckPos", NbtUtils.writeBlockPos(stuckPos));
        tag.put("Item", stack.save(new CompoundTag()));
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setState(tag.getInt("State"));
        if (tag.contains("StuckPos")) {
            stuckPos = NbtUtils.readBlockPos(tag.getCompound("StuckPos"));
        }
        if (tag.contains("Item")) {
            stack = ItemStack.of(tag.getCompound("Item"));
        }
        if (stack.isEmpty()) {
            stack = new ItemStack(ModItems.MJOLNIR.get());
        }
    }
}
