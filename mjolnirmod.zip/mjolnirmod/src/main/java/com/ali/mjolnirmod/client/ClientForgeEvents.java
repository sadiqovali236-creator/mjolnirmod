package com.ali.mjolnirmod.client;

import com.ali.mjolnirmod.ModItems;
import com.ali.mjolnirmod.MjolnirMod;
import com.ali.mjolnirmod.item.MjolnirItem;
import com.ali.mjolnirmod.network.MjolnirActionPacket;
import com.ali.mjolnirmod.network.MjolnirActions;
import com.ali.mjolnirmod.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MjolnirMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientForgeEvents {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        boolean lightningPressed = false;
        while (ModKeys.LIGHTNING.consumeClick()) {
            lightningPressed = true;
        }

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null) {
            ClientState.reset();
            return;
        }

        boolean holding = player.getMainHandItem().is(ModItems.MJOLNIR.get()) && MjolnirItem.isWorthy(player);
        boolean useDown = mc.options.keyUse.isDown();

        if (holding && useDown) {
            // Blok koyma tusu basili: cekic doner
            ClientState.tickCharge();
        } else {
            // Birakildi: yeterince beklendiyse firlat
            if (ClientState.charging && holding && ClientState.charge >= MjolnirActions.MIN_CHARGE) {
                ModNetwork.CHANNEL.sendToServer(
                        new MjolnirActionPacket(MjolnirActionPacket.THROW, ClientState.charge));
            }
            ClientState.reset();
        }

        if (lightningPressed && holding) {
            ModNetwork.CHANNEL.sendToServer(new MjolnirActionPacket(MjolnirActionPacket.LIGHTNING, 0));
        }
    }

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        // Blok koyma / kullanma tusu. Vurma tusu normal calisir.
        if (!event.isUseItem() || event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }

        boolean mjolnirInHand = player.getMainHandItem().is(ModItems.MJOLNIR.get());
        if (mjolnirInHand) {
            if (MjolnirItem.isWorthy(player)) {
                // Blok koymasin / kapi acmasin, firlatma sistemi calissin
                event.setSwingHand(false);
                event.setCanceled(true);
            }
        } else {
            // Elde cekic yok: ayni tus, firlatilmis cekici geri cagirir
            ModNetwork.CHANNEL.sendToServer(new MjolnirActionPacket(MjolnirActionPacket.RECALL, 0));
        }
    }
}
