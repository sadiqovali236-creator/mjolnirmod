package com.ali.mjolnirmod.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

public class ModKeys {
    /** Ayarlar > Kontroller > Mjolnir bolumunden degistirilebilir. */
    public static final KeyMapping LIGHTNING = new KeyMapping(
            "key.mjolnirmod.lightning",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_R,
            "key.categories.mjolnirmod");
}
