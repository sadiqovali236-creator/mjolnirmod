package com.ali.mjolnirmod;

import com.ali.mjolnirmod.entity.MjolnirEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MjolnirMod.MOD_ID);

    public static final RegistryObject<EntityType<MjolnirEntity>> MJOLNIR = ENTITIES.register("mjolnir",
            () -> EntityType.Builder.<MjolnirEntity>of((type, level) -> new MjolnirEntity(type, level), MobCategory.MISC)
                    .sized(0.6F, 0.6F)
                    .clientTrackingRange(8)
                    .updateInterval(1)
                    .fireImmune()
                    .build("mjolnir"));
}
