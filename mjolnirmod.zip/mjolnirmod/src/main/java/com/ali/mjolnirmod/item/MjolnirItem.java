package com.ali.mjolnirmod.item;

import com.ali.mjolnirmod.client.ClientState;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Consumer;

public class MjolnirItem extends Item {
    /** Mjolniri kaldirmak / kullanmak icin gereken seviye. */
    public static final int WORTHY_LEVEL = 50;

    public MjolnirItem(Properties properties) {
        super(properties);
    }

    public static boolean isWorthy(Player player) {
        return player.isCreative() || player.experienceLevel >= WORTHY_LEVEL;
    }

    // Normal vurus hasari (Guc II ile birlikte)
    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot == EquipmentSlot.MAINHAND) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.put(Attributes.ATTACK_DAMAGE,
                    new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier", 11.0D,
                            AttributeModifier.Operation.ADDITION));
            builder.put(Attributes.ATTACK_SPEED,
                    new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier", -2.8D,
                            AttributeModifier.Operation.ADDITION));
            return builder.build();
        }
        return super.getDefaultAttributeModifiers(slot);
    }

    // Elindeyken guc verir
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide() || !selected || !(entity instanceof Player player) || !isWorthy(player)) {
            return;
        }
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 40, 1, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 0, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.JUMP, 40, 1, true, false, true));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.mjolnirmod.throw"));
        tooltip.add(Component.translatable("tooltip.mjolnirmod.recall"));
        tooltip.add(Component.translatable("tooltip.mjolnirmod.lightning"));
        tooltip.add(Component.translatable("tooltip.mjolnirmod.worthy", WORTHY_LEVEL));
    }

    // Blok koyma tusu basili tutarken eldeki cekic doner (sadece goruntu)
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public boolean applyForgeHandTransform(PoseStack poseStack, LocalPlayer player, HumanoidArm arm,
                                                   ItemStack itemInHand, float partialTick,
                                                   float equipProcess, float swingProcess) {
                if (!ClientState.charging) {
                    return false;
                }
                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                poseStack.translate(side * 0.56F, -0.52F + equipProcess * -0.6F, -0.72F);
                float spin = (player.tickCount + partialTick) * 55.0F;
                poseStack.translate(0.0F, 0.2F, 0.0F);
                poseStack.mulPose(Axis.ZP.rotationDegrees(spin));
                poseStack.translate(0.0F, -0.2F, 0.0F);
                return true;
            }
        });
    }
}
