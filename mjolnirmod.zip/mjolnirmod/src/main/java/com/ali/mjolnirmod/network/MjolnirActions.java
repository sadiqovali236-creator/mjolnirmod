package com.ali.mjolnirmod.network;

import com.ali.mjolnirmod.ModItems;
import com.ali.mjolnirmod.entity.MjolnirEntity;
import com.ali.mjolnirmod.item.MjolnirItem;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.entity.EntityTypeTest;

import java.util.List;

/** Sunucu tarafi: oyuncunun Mjolnir komutlarini isler. */
public class MjolnirActions {
    public static final int MIN_CHARGE = 5;
    public static final int MAX_CHARGE = 30;

    private static final double BEAM_RANGE = 48.0D;
    private static final float BEAM_DAMAGE = 10.0F;
    private static final int BEAM_COOLDOWN = 40;

    public static void handle(ServerPlayer player, byte action, int charge) {
        switch (action) {
            case MjolnirActionPacket.THROW -> throwHammer(player, charge);
            case MjolnirActionPacket.RECALL -> recall(player);
            case MjolnirActionPacket.LIGHTNING -> lightningBeam(player);
            default -> { }
        }
    }

    private static boolean canUse(ServerPlayer player, ItemStack held) {
        return held.is(ModItems.MJOLNIR.get()) && MjolnirItem.isWorthy(player);
    }

    private static void throwHammer(ServerPlayer player, int charge) {
        ItemStack held = player.getMainHandItem();
        if (!canUse(player, held) || charge < MIN_CHARGE) {
            return;
        }

        int clamped = Math.min(charge, MAX_CHARGE);
        MjolnirEntity hammer = new MjolnirEntity(player.level(), player);
        hammer.setStack(held);
        float speed = 1.5F + (float) clamped / MAX_CHARGE;
        hammer.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, speed, 0.0F);
        player.level().addFreshEntity(hammer);

        player.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 1.0F, 0.8F);
    }

    private static void recall(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        List<? extends MjolnirEntity> hammers = level.getEntities(
                EntityTypeTest.forClass(MjolnirEntity.class),
                e -> e.getOwner() == player);
        for (MjolnirEntity hammer : hammers) {
            hammer.startReturning();
        }
    }

    private static void lightningBeam(ServerPlayer player) {
        ItemStack held = player.getMainHandItem();
        if (!canUse(player, held) || player.getCooldowns().isOnCooldown(held.getItem())) {
            return;
        }

        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = eye.add(look.scale(BEAM_RANGE));

        BlockHitResult hit = level.clip(
                new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        boolean hitBlock = hit.getType() != HitResult.Type.MISS;
        Vec3 target = hitBlock ? hit.getLocation() : end;

        // Isin: kivilcim cizgisi
        double length = eye.distanceTo(target);
        for (double d = 1.0D; d < length; d += 0.6D) {
            Vec3 point = eye.add(look.scale(d));
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                    point.x, point.y - 0.15D, point.z, 2, 0.1D, 0.1D, 0.1D, 0.05D);
        }

        // Isinin yolundaki canlilara hasar
        AABB area = new AABB(eye, target).inflate(2.0D);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area,
                e -> e != player && e.isAlive())) {
            AABB box = entity.getBoundingBox().inflate(0.7D);
            if (box.contains(eye) || box.clip(eye, target).isPresent()) {
                entity.hurt(level.damageSources().lightningBolt(), BEAM_DAMAGE);
                entity.setSecondsOnFire(4);
            }
        }

        // Varis noktasinda yildirim
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(target);
            bolt.setCause(player);
            bolt.setVisualOnly(!hitBlock);
            level.addFreshEntity(bolt);
        }

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 2.0F, 1.2F);
        player.getCooldowns().addCooldown(held.getItem(), BEAM_COOLDOWN);
    }
}
